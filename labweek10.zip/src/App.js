//import logo from './logo.svg';
import { useState } from "react";
import './App.css';

const App = () => {
  const [nameField, setNameField] = useState("");
  const [emailField, setEmailField] = useState("");
  const [addressField, setAddressField] = useState("");
  const [addressField2, setAddressField2] = useState("");
  const [cityField, setCityField] = useState("");
  const [provinceField, setProvinceField] = useState("");
  const [postCodeField, setPostCodeField] = useState("");

  const [showNameField, setShowNameField] = useState(false);
  const [showEmailField, setShowEmailField] = useState(false);
  const [showAddressField, setShowAddressField] = useState(false);
  const [showAddressField2, setShowAddressField2] = useState(false);
  const [showCityField, setShowCityField] = useState(false);
  const [showProvinceField, setShowProvinceField] = useState(false);
  const [showPostCodeField, setShowPostCodeField] = useState(false);
  
  let subnsnHandlerMethod = (evt) => {
    evt.preventDefault();
    setShowNameField(true);
    setShowEmailField(true);
    setShowAddressField(true);
    setShowAddressField2(true);
    setShowCityField(true);
    setShowProvinceField(true);
    setShowPostCodeField(true);
  };

  return (
    <>
      <form onSubmit={subnsnHandlerMethod}>
        <h2>Data Entry Form</h2>
        <div className="top">
          <div>
            <label htmlFor="emBox">Email</label>
            <input type="email" id="emBox" placeholder="Enter email" value={emailField} onChange={(evt) => setEmailField(evt.target.value)}/>
          </div>
          <div>
            <label htmlFor="nameBox">Name</label>
            <input type="text" id="nameBox" placeholder="Full Name" value={nameField} onChange={(evt) => setNameField(evt.target.value)}/>
          </div>
        </div>
            <label htmlFor="addressBox">Address</label>
            <input type="text" id="addressBox" placeholder="1234 Main St" value={addressField} onChange={(evt) => setAddressField(evt.target.value)}/>
            <label htmlFor="address2Box">Address 2</label>
            <input type="text" id="address2Box" placeholder="Apartment, studio, or floor" value={addressField2} onChange={(evt) => setAddressField2(evt.target.value)}/>
            <div className="btm">
              <div>
                <label htmlFor="cityBox">City</label>
                <input type="text" id="cityBox" value={cityField} onChange={(evt) => setCityField(evt.target.value)}/>
              </div>
              <div>
                <label htmlFor="prvncBox" id="prncBox">Province</label>
                <select id="prvncBox" value={provinceField} onChange={(evt) => setProvinceField(evt.target.value)}>
                  <option value="Alberta" id="1">Alberta</option>
                  <option value="British Columbia" id="2">British Columbia</option>
                  <option value="Manitoba" id="3">Manitoba</option>
                  <option value="New Brunswick" id="4">New Brunswick</option>
                  <option value="Newfoundland and Laborer" id="5">Newfoundland and Laborer</option>
                  <option value="Nova Scotia" id="6">Nova Scotia</option>
                  <option value="Ontario" id="7">Ontario</option>
                  <option value="Prince Edward Island" id="8">Prince Edward Island</option>
                  <option value="Quebec" id="9">Quebec</option>
                  <option value="Saskatchewan" id="10">Saskatchewan</option>
                </select>
              </div>
              <div>
                <label htmlFor="postBox">Postal Code</label>
                <input type="text" id="postBox" value={postCodeField} onChange={(evt) => setPostCodeField(evt.target.value)}/>
              </div>
            </div>
            <input type="checkbox" id="chck"/> Agree Terms &amp; Condition?
            <input type="submit" value="Submit" id="Subbtn"/>
      </form>
      <table className="output">
        <tr>{showNameField ? (<><td className='op'>Full name:</td> {nameField}</>) : ''}</tr>
        <tr>{showEmailField ? (<><td className='op'>Email:</td> {emailField}</>) : ''}</tr>
        <tr>{showAddressField ? (<><td className='op'>Address:</td> {addressField}</>) : ''}</tr>
        <tr>{showAddressField2 ? (<><td className='op'>Address 2:</td> {addressField2}</>) : ''}</tr>
        <tr>{showCityField ? (<><td className='op'>City:</td> {cityField}</>) : ''}</tr>
        <tr>{showProvinceField ? (<><td className='op'>Province:</td> {provinceField}</>) : ''}</tr>
        <tr>{showPostCodeField ? (<><td className='op'>Post code:</td> {postCodeField}</>) : ''}</tr>
      </table>
    </>
  );
}

 export default App;
